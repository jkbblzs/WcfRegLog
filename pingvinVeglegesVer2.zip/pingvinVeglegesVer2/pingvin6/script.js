function registers() {
  document.getElementById('keret').innerHTML
      =  `<div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5">
            <div class="text-center">
              <img src="https://cdn.pixabay.com/photo/2016/03/31/19/56/avatar-1295397__340.png" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3"
                width="200px" alt="profile">
            </div>
            <div class="mb-3">
            <input type="text" class="form-control" id="FullName"
              placeholder="Enter Full Name" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" id="Username" aria-describedby="emailHelp"
                placeholder="Enter Username" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" id="Email" placeholder="Enter Email" required>
            </div>
            <div class="mb-3">
              <input type="password" class="form-control" id="Password" placeholder="Enter Password" required>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-color px-5 mb-3 w-100" onclick=handleRegister()>Register</button>
            </div>
            <button type="submit" class="btn btn-color px-3 float-left" onclick=cancel()>Cancel</button> 
          </form>
        </div>
      </div>
    </div>`
}

function cancel(){
  
  document.getElementById('keret').innerHTML
      =  `<div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5">
            <div class="text-center">
              <img src="https://cdn.pixabay.com/photo/2016/03/31/19/56/avatar-1295397__340.png" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3"
                width="200px" alt="profile">
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" id="Username" aria-describedby="emailHelp"
                placeholder="Enter Username" required>
            </div>
            <div class="mb-3">
              <input type="password" class="form-control" id="Password" placeholder="Enter Password" required>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-color px-5 mb-3 w-100" onclick=handleClick()>Login</button>
              <button type="submit" class="btn btn-color px-5 mb-3 w-100" onclick=registers()>Register</button>
            </div>
            <button type="submit" class="btn btn-color px-3 float-left" onclick=cancel()>Cancel</button>
          </form>
        </div>
      </div>
    </div>`
}