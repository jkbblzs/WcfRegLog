async function doGetRequest() {

  let res = await axios.get('http://localhost:56839/Service1.svc/getUserss');

  let data = res.data;
  return await data;
}

async function getData() {
  console.log('asdasd')
  console.log(location.href)
  if (location.href != "http://127.0.0.1:5500/update.html") {
    const userList = await doGetRequest();
    console.log(userList);

    const thead = document.querySelector('thead');
    thead.innerHTML = `<tr>
    <th>Id</th>
    <th>Username</th>
    <th>E-mail</th>
    <th>Password</th>
    <th>Fullname</th>
    <th>Active</th>
    <th>Rank</th>
    <th>Ban</th>
    <th>Módosítás/Törlés</th>
  </tr>`

    const tbody = document.querySelector('tbody');

    for (let user of userList) {
      tbody.insertAdjacentHTML('beforeend', `<tr>
        <td>${user.Id}</td>
        <td>${user.Uname}</td>
        <td>${user.Email}</td>
        <td>${user.Pwd}</td>
        <td>${user.FullName}</td>
        <td>${user.Active}</td>
        <td>${user.Rank}</td>
        <td>${user.Ban}</td>
        <td>
          <button class="edit">Edit</button>
          <button class="delete">Delete</button>
        </td>
      </tr>`)
    }
  } else {
    return;
  }
}

async function deleteRequest() {
  if (location.href != "http://127.0.0.1:5500/update.html") {

    const buttons = document.querySelectorAll('.delete');
    buttons.forEach(button => button.addEventListener('click', async () => {
      const tr = button.parentNode.parentNode;
      const Id = tr.children[0].textContent;
      console.log(Id);
      let res = await axios.delete('http://localhost:56839/Service1.svc/deleteUsers' + `/${Id}`);

      location.reload();
    }))
  } else {
    return;
  }
}

async function updateUser2(Id) {
 
  const usernameInput = document.querySelector('.username');
  const emailInput = document.querySelector('.email');
  const passwordInput = document.querySelector('.password');
  const fullnameInput = document.querySelector('.fullname');
  const activeInput = document.querySelector('.active');
  const rankInput = document.querySelector('.rank');
  const banInput = document.querySelector('.ban');
  const data = 
  {
          Id: Id,
          Uname: usernameInput.value,
          Email: emailInput.value,
          Pwd: passwordInput.value,
          FullName: fullnameInput.value,
          Active: activeInput.value,
          Rank: rankInput.value,
          Ban: banInput.value,
  }
  const response = await axios.put("http://localhost:56839/Service1.svc/putCustomer",data).then(function(response){
    console.log(response);
    return response;
  })
}



async function mukodj() {
  const editButtons = document.querySelectorAll('.edit');
    editButtons.forEach(button => button.addEventListener('click', () => {
        const tr = button.parentNode.parentNode;
        const Id = tr.children[0].textContent;
        const UName = tr.children[1].textContent;
        const Email = tr.children[2].textContent;
        const Pwd = tr.children[3].textContent;
        const Fullname = tr.children[4].textContent;
        const Active = tr.children[5].textContent;
        const Rank = tr.children[6].textContent;
        const Ban = tr.children[7].textContent;

        document.body.innerHTML = `
        <div id="keret" class="container">
        <div class="row">
          <div class="col-md-6 offset-md-3">
            <div class="card my-5">
              <form class="card-body cardbody-color p-lg-5">
                <div class="text-center">
                  <img src="https://cdn.pixabay.com/photo/2016/03/31/19/56/avatar-1295397__340.png" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3" width="200px" alt="profile">
                </div>
                <div class="mb-3">
                    <label for="exampleInputusername1" class="form-label">Username</label>
                    <input value="${UName}" type="text" class="form-control username" id="exampleInputusername1" aria-describedby="usernameHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">E-mail</label>
                    <input value="${Email}" type="email" class="form-control email" id="exampleInputEmail1">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input value="${Pwd}" type="password" class="form-control password" id="exampleInputPassword1" aria-describedby="passwordHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputFullname1" class="form-label">Full Name</label>
                    <input value="${Fullname}" type="text" class="form-control fullname" id="exampleInputFullname1">
                </div>
                <div class="mb-3">
                    <label for="exampleInputActive1" class="form-label">Active</label>
                    <input value="${Active}" type="string" class="form-control active" id="exampleInputActive1" aria-describedby="activeHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputRank1" class="form-label">Rank</label>
                    <input value="${Rank}" type="string" class="form-control rank" id="exampleInputRank1">
                </div>
                <div class="mb-3">
                    <label for="exampleInputBan1" class="form-label">Ban</label>
                    <input value="${Ban}" type="string" class="form-control ban" id="exampleInputBan1" aria-describedby="BanHelp">
                </div>
                <div class="text-center">
                  <button id="editButton" type="submit" class="btn btn-color px-5 w-100 edit__user">Edit User</button>
                </div>  
              </form>
            </div>
          </div>
        </div>
      </div>`

    const editButton = document.querySelector('.edit__user');
        editButton.addEventListener('click', async (event) => {
          event.preventDefault();
          await updateUser2(Id);
          alert("Az adatok módosítása sikeresen megtörtént!");
          location.href="loggedState.html";
      })
  }))
}

(async function awaitAll() {
  await getData();
  await deleteRequest();
  await mukodj();
})()