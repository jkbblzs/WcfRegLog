function handleClick(){
  event.preventDefault();
    username = document.getElementById("Username").value;
    password = document.getElementById("Password").value;
    console.log(username);
    console.log(password);
    axios.get("http://localhost:56839/Service1.svc/getUsers/"+username+"/"+password).then(function(res){
      console.log(res);
      if(res.data === ""){
        alert("Sikertelen bejelentkezés!");
      }
      else{
        document.getElementById("loginbtn").onclick=location.href="loggedState.html";
      }
    })
}

function showPassword(){
  var x = document.getElementById("Password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

  function handleRegister(){
    event.preventDefault();
    const data = 
    {
      Active: 0,
      Ban: 0,
      Email: document.getElementById("Email").value,
      FullName: document.getElementById("FullName").value,
      Id: 0,
      Pwd: document.getElementById("Password").value,
      Rank: 0,
      Uname: document.getElementById("Username").value
    }
    if(document.getElementById("Email").value != '' && document.getElementById("FullName").value != '' && document.getElementById("Password").value != '' && document.getElementById("Username").value != '')
    {
      alert("Sikeres regisztráció!");
    }
    else
    {
        alert("A regisztrációhoz tölsd ki az összes mezőt!");
        return;
    }
    axios.post("http://localhost:56839/Service1.svc/postCustomer",data).then(function(res){
      console.log(res);
      
        alert(res.data.postCustomerResult);
    })
}