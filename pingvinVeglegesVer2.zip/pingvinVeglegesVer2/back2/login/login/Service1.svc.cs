﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace login
{
    
    public class Service1 : IService1
    {
        Connect c = new Connect();
        List<Users> cust = new List<Users>();
        public List<Users> getUserss()
        {
            string qry = "SELECT * FROM users";

            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = c.connection;
            cmd.CommandText = qry;

            MySqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Users Users = new Users();

                Users.Id = dr.GetInt32(0);
                Users.Uname = dr.GetString(1);
                Users.Email = dr.GetString(2);
                Users.Pwd = dr.GetString(3);
                Users.FullName = dr.GetString(4);
                Users.Active = dr.GetInt32(5);
                Users.Rank = dr.GetInt32(6);
                Users.Ban = dr.GetInt32(7);


                cust.Add(Users);
            }

            return cust;

        }
        public Users getUsers(string uname,string pwd)
        {
            
                
                string qry = "SELECT * FROM `users` WHERE uname=@uname AND pwd=@pwd";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = c.connection;
                cmd.Parameters.AddWithValue("@uname", uname);
                cmd.Parameters.AddWithValue("@pwd", pwd);
                cmd.CommandText = qry;

                MySqlDataReader dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                {
                    return null;
                }
                dr.Read();

                Users Users = new Users();

                Users.Id = dr.GetInt32(0);
                Users.Uname = dr.GetString(1);
                Users.Email = dr.GetString(2);
                Users.Pwd = dr.GetString(3);
                Users.FullName = dr.GetString(4);
                Users.Active = dr.GetInt32(5);
                Users.Rank = dr.GetInt32(6);
                Users.Ban = dr.GetInt32(7);


                dr.Close();
                return Users;
            

        }

        public string deleteUsers(string id)//*Ok
        {
            try
            {
                string qry = "DELETE FROM Users WHERE id=" + id;
                MySqlCommand cmd = new MySqlCommand(qry, c.connection);

                cmd.ExecuteNonQuery();

                return "Felhasználó törölve!";
            }
            catch (Exception e)
            {
                return e.Message;
            }

        }

        public string putUsers(string id, string uname, string email, string pwd, string fullname, int active, int rank, int ban)//*Ok
        {
            try
            {
                string qry = "UPDATE `Users` SET `uname`=@uname,`email`=@email,`pwd`=@pwd,`fullname`=@fullname,`active`=@active,`rank`=@rank,`ban`=@ban WHERE id=@id;";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = c.connection;
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@uname", uname);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@pwd", pwd);
                cmd.Parameters.AddWithValue("@fullname", fullname);
                cmd.Parameters.AddWithValue("@active", active);
                cmd.Parameters.AddWithValue("@rank", rank);
                cmd.Parameters.AddWithValue("@ban", ban);
                cmd.CommandText = qry;

                cmd.ExecuteNonQuery();

                return "Módosítás elvégezve!";
            }
            catch (Exception e)
            {

                return e.Message;
            }
        }


        public string putCustomer(Users user)//*Ok
        {
            if (user != null)
            {
                try
                {
                    string qry = "UPDATE `users` SET `uname`=@uname,`email`=@email,`pwd`=@pwd,`fullname`=@fullname,`active`=@active,`rank`=@rank,`ban`=@ban WHERE `id`=@id;";

                    MySqlCommand cmd = new MySqlCommand();
                    cmd.Connection = c.connection;
                    cmd.Parameters.AddWithValue("@id", user.Id);
                    cmd.Parameters.AddWithValue("@uname", user.Uname);
                    cmd.Parameters.AddWithValue("@email", user.Email);
                    cmd.Parameters.AddWithValue("@pwd", user.Pwd);
                    cmd.Parameters.AddWithValue("@fullname", user.FullName);
                    cmd.Parameters.AddWithValue("@active", user.Active);
                    cmd.Parameters.AddWithValue("@rank", user.Rank);
                    cmd.Parameters.AddWithValue("@ban", user.Ban);
                    cmd.CommandText = qry;

                    cmd.ExecuteNonQuery();

                    return "Módosítás sikeresen elvégezve!";
                }
                catch (Exception e)
                {

                    return e.Message;
                }
            }
            else
            {
                return "Nullt kaptam";
            }
        }

        public string postCustomer(Users customer)//*Ok
        {
            if (customer != null)
            {
                try
                {
                    string qry = "INSERT INTO `users`(`uname`, `email`, `pwd`, `fullname`, `active`, `rank`, `ban`) " +
                        "VALUES (@uname, @email, @pwd, @fullname, @active, @rank, @ban);";

                    MySqlCommand cmd = new MySqlCommand();
                    cmd.Connection = c.connection;
                    cmd.Parameters.AddWithValue("@uname", customer.Uname);
                    cmd.Parameters.AddWithValue("@email", customer.Email);
                    cmd.Parameters.AddWithValue("@pwd", customer.Pwd);
                    cmd.Parameters.AddWithValue("@fullname", customer.FullName);
                    cmd.Parameters.AddWithValue("@active", customer.Active);
                    cmd.Parameters.AddWithValue("@rank", customer.Rank);
                    cmd.Parameters.AddWithValue("@ban", customer.Ban);
                    cmd.CommandText = qry;
                    cmd.ExecuteNonQuery();

                    return "Felhasználó sikeresen hozzáadva!";
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            else
            {
                return "Nincs törzse a végpontnak!";
            }
        }
    }
}
