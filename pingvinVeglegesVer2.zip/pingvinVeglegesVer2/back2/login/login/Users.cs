﻿using System.Runtime.Serialization;

namespace login
{
    public class Users
    {
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public string Uname { get; set; }

        [DataMember]
        public string Email { get; set; }

        [DataMember]
        public string Pwd { get; set; }

        [DataMember]
        public string FullName { get; set; }

        [DataMember]
        public int Active { get; set; }

        [DataMember]
        public int Rank { get; set; }

        [DataMember]
        public int Ban { get; set; }

    }
}